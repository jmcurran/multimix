# # grout <- read.table('groups.out', header = FALSE) head(grout) n <- dim(grout)[1] nc <- dim(grout)[2]
# gr_asgd <- grout[, 1] log_dens <- grout[, nc] Z <- as.matrix(grout[, -c(1, nc)]) colnames(Z) <- NULL
# head(Z) plot(log_dens)
